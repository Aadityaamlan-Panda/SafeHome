@app.route("/safe_route", methods=["GET"])
def safe_route():
    origin = request.args.get("origin")
    destination = request.args.get("destination")
    step_size = float(request.args.get("step_size", 0.5))  # Default step size
    max_iterations = 10000  # Fail-safe iteration limit
    risk_threshold = 70  # Threshold for high disaster risk
    retry_limit = 5  # Max retries for high-risk adjustments

    def get_coordinates(location):
        try:
            response = requests.get(
                f"https://api.opencagedata.com/geocode/v1/json?q={location}&key={OPENCAGE_API_KEY}"
            )
            response.raise_for_status()
            data = response.json()
            if data.get("results"):
                coords = data["results"][0]["geometry"]
                return coords["lat"], coords["lng"]
            return None, None
        except requests.exceptions.RequestException as e:
            print(f"Error fetching coordinates for {location}: {e}")
            return None, None

    def get_address(lat, lon):
        try:
            response = requests.get(
                f"https://api.opencagedata.com/geocode/v1/json?q={lat}+{lon}&key={OPENCAGE_API_KEY}"
            )
            response.raise_for_status()
            data = response.json()
            if data.get("results"):
                return data["results"][0]["formatted"]
            return "Unknown location"
        except requests.exceptions.RequestException as e:
            print(f"Error reverse geocoding for ({lat}, {lon}): {e}")
            return "Error retrieving location"

    origin_lat, origin_lon = get_coordinates(origin)
    dest_lat, dest_lon = get_coordinates(destination)

    if origin_lat is None or dest_lat is None:
        return jsonify({"error": "Unable to fetch coordinates for one or both locations."}), 400

    current_lat, current_lon = origin_lat, origin_lon
    route_path = [{"lat": current_lat, "lon": current_lon, "address": get_address(current_lat, current_lon)}]
    disaster_free_path = True
    visited_high_risk = set()
    iteration = 0

    while iteration < max_iterations:
        iteration += 1

        # Calculate the distance to the destination
        lat_diff = dest_lat - current_lat
        lon_diff = dest_lon - current_lon

        # Check if destination is reached within the step size
        if abs(lat_diff) < step_size and abs(lon_diff) < step_size:
            # Add final destination to the route path
            route_path.append({
                "lat": dest_lat,
                "lon": dest_lon,
                "address": get_address(dest_lat, dest_lon)
            })
            break

        # Normalize the step size to avoid overshooting
        step_lat = step_size if lat_diff > 0 else -step_size
        step_lon = step_size if lon_diff > 0 else -step_size

        # Step towards the destination
        new_lat = current_lat + (step_lat if abs(lat_diff) > step_size else lat_diff)
        new_lon = current_lon + (step_lon if abs(lon_diff) > step_size else lon_diff)

        retries = 0
        while retries < retry_limit:
            try:
                # Check disaster predictions at the new location
                disaster_response = requests.get(
                    f"http://127.0.0.1:5000/get_disaster_prediction?lat={new_lat}&lon={new_lon}"
                )
                disaster_response.raise_for_status()
                disaster_data = disaster_response.json()

                # If high disaster probability, adjust the route
                high_risk = any(pred["probability"] > risk_threshold for pred in disaster_data.get("predictions", []))
                if high_risk:
                    disaster_free_path = False
                    print(f"High disaster risk at ({new_lat}, {new_lon}). Adjusting route.")

                    # Mark the location as visited and adjust direction
                    visited_high_risk.add((new_lat, new_lon))
                    retries += 1

                    # Try a different direction
                    new_lat += step_size * (-1 if retries % 2 == 0 else 1)  # Alternate adjustments
                    new_lon += step_size * (1 if retries % 2 == 0 else -1)
                else:
                    break  # Safe location found
            except requests.exceptions.RequestException as e:
                print(f"Error fetching disaster data for ({new_lat}, {new_lon}): {e}")
                retries += 1

        if retries >= retry_limit:
            print(f"Unable to find safe path around ({current_lat}, {current_lon}). Continuing anyway.")

        # Move to the new location
        current_lat, current_lon = new_lat, new_lon

        # Add the current point to the route path with reverse geocoding
        route_path.append({
            "lat": current_lat,
            "lon": current_lon,
            "address": get_address(current_lat, current_lon)
        })

    if iteration >= max_iterations:
        return jsonify({"error": "Failed to compute a safe route within the iteration limit."}), 500

    result = {
        "origin": {
            "lat": origin_lat,
            "lon": origin_lon,
            "address": get_address(origin_lat, origin_lon)
        },
        "destination": {
            "lat": dest_lat,
            "lon": dest_lon,
            "address": get_address(dest_lat, dest_lon)
        },
        "route_path": route_path,
        "disaster_free": disaster_free_path,
    }
    return jsonify(result)