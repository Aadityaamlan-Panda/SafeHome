import os
import sqlite3
from flask import Flask, render_template, request, jsonify
import requests
import json
from datetime import datetime

app = Flask(__name__)

# API Keys
WEATHER_API_KEY = " "  # OpenWeatherMap API Key
OPENCAGE_API_KEY = " "  # OpenCage API Key

DATABASE = "family_messages.db"  # SQLite database file

# Function to initialize the database and create table if not exists
def init_db():
    """Initialize the database with the necessary table."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        family_member TEXT NOT NULL,
        message TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')
    conn.commit()
    conn.close()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_weather", methods=["GET"])
def get_weather():
    lat = request.args.get("lat")
    lon = request.args.get("lon")
    try:
        response = requests.get(
            f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}"
        )
        response.raise_for_status()
        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to fetch weather data: {e}"}), 500

@app.route("/get_disaster_prediction", methods=["GET"])
def get_disaster_prediction():
    lat = request.args.get("lat")
    lon = request.args.get("lon")

    if not lat or not lon:
        return jsonify({"error": "Latitude and longitude are required."}), 400

    try:
        weather_response = requests.get(
            f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}"
        )
        weather_response.raise_for_status()
        weather_data = weather_response.json()

        temperature = weather_data["main"]["temp"] - 273.15  # Kelvin to Celsius
        wind_speed = weather_data["wind"]["speed"]
        humidity = weather_data["main"]["humidity"]


        predictions = []
        messages = []  # This will hold all print messages for frontend display

        # Flood prediction
        if humidity > 85:
            predictions.append({"type": "Flood", "probability": 80})
            messages.append("High humidity detected (>85%), significant flood risk.")
        elif humidity > 75 and temperature > 30:
            predictions.append({"type": "Flood", "probability": 60})
            messages.append("Moderate flood risk due to high humidity and temperature (>30°C).")

        # Wildfire prediction
        if temperature > 40 and humidity < 30:
            predictions.append({"type": "Wildfire", "probability": 90})
            messages.append("Severe wildfire risk detected: High temperature (>40°C) and low humidity (<30%).")
        elif temperature > 35 and humidity < 40:
            predictions.append({"type": "Wildfire", "probability": 75})
            messages.append("Moderate wildfire risk due to high temperature (>35°C) and low humidity (<40%).")

        # Hurricane prediction
        if wind_speed > 30:
            predictions.append({"type": "Hurricane", "probability": 85})
            messages.append("Hurricane warning: Winds exceed 30 km/h.")
        elif wind_speed > 25:
            predictions.append({"type": "Hurricane", "probability": 70})
            messages.append("Hurricane risk: Winds between 25-30 km/h.")

        # Tornado prediction
        if wind_speed > 25 and humidity < 50:
            predictions.append({"type": "Tornado", "probability": 70})
            messages.append("Tornado risk: Strong winds (>25 km/h) and low humidity (<50%).")
        elif wind_speed > 20:
            predictions.append({"type": "Tornado", "probability": 50})
            messages.append("Moderate tornado risk: Winds between 20-25 km/h.")

        # Severe storm prediction
        if humidity > 95 and wind_speed > 15:
            predictions.append({"type": "Severe Storm", "probability": 80})
            messages.append("Severe storm risk: Extremely high humidity (>95%) and strong winds (>15 km/h).")

        # Return predictions along with messages
        return jsonify({"predictions": predictions, "messages": messages})

    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to fetch data: {e}"}), 500

@app.route("/emergency_plan", methods=["GET"])
def emergency_plan():
    disaster_type = request.args.get("disaster_type")
    plans = {
        "earthquake": {
            "plan": "Drop, cover, and hold on. Secure heavy objects.",
            "link": "https://www.ready.gov/earthquakes",
        },
        "flood": {
            "plan": "Move to higher ground. Avoid floodwaters.",
            "link": "https://www.ready.gov/floods",
        },
        "hurricane": {
            "plan": "Stay indoors and away from windows.",
            "link": "https://www.ready.gov/hurricanes",
        },
        "wildfire": {
            "plan": "Evacuate if instructed. Avoid smoke inhalation.",
            "link": "https://www.ready.gov/wildfires",
        },
        "tornado": {
            "plan": "Take shelter in a basement or an interior room.",
            "link": "https://www.ready.gov/tornadoes",
        },
    }
    plan = plans.get(disaster_type, {"plan": "No plan available.", "link": ""})
    return jsonify(plan)

@app.route("/safe_route", methods=["GET"])
def safe_route():
    origin = request.args.get("origin")
    destination = request.args.get("destination")
    step_size = float(request.args.get("step_size", 0.5))  # Default step size
    max_iterations = 10000  # Fail-safe iteration limit
    risk_threshold = 70  # Threshold for high disaster risk
    retry_limit = 5  # Max retries for high-risk adjustments
    long_jump_factor = 0.1 # Factor by which to increase the step size during high-risk areas

    def get_coordinates(location):
        try:
            response = requests.get(
                f"https://api.opencagedata.com/geocode/v1/json?q={location}&key={OPENCAGE_API_KEY}"
            )
            response.raise_for_status()
            data = response.json()
            if data.get("results"):
                coords = data["results"][0]["geometry"]
                return coords["lat"], coords["lng"]
            return None, None
        except requests.exceptions.RequestException as e:
            print(f"Error fetching coordinates for {location}: {e}")
            return None, None

    def get_address(lat, lon):
        try:
            response = requests.get(
                f"https://api.opencagedata.com/geocode/v1/json?q={lat}+{lon}&key={OPENCAGE_API_KEY}"
            )
            response.raise_for_status()
            data = response.json()
            if data.get("results"):
                return data["results"][0]["formatted"]
            return "Unknown location"
        except requests.exceptions.RequestException as e:
            print(f"Error reverse geocoding for ({lat}, {lon}): {e}")
            return "Error retrieving location"

    origin_lat, origin_lon = get_coordinates(origin)
    dest_lat, dest_lon = get_coordinates(destination)

    if origin_lat is None or dest_lat is None:
        return jsonify({"error": "Unable to fetch coordinates for one or both locations."}), 400

    current_lat, current_lon = origin_lat, origin_lon
    route_path = [{"lat": current_lat, "lon": current_lon, "address": get_address(current_lat, current_lon)}]
    disaster_free_path = True
    visited_high_risk = set()
    iteration = 0

    while iteration < max_iterations:
        iteration += 1

        # Calculate the distance to the destination
        lat_diff = dest_lat - current_lat
        lon_diff = dest_lon - current_lon

        # Check if destination is reached within the step size
        if abs(lat_diff) < step_size and abs(lon_diff) < step_size:
            # Add final destination to the route path
            route_path.append({
                "lat": dest_lat,
                "lon": dest_lon,
                "address": get_address(dest_lat, dest_lon)
            })
            break

        # Normalize the step size to avoid overshooting
        step_lat = step_size if lat_diff > 0 else -step_size
        step_lon = step_size if lon_diff > 0 else -step_size

        # Step towards the destination
        new_lat = current_lat + (step_lat if abs(lat_diff) > step_size else lat_diff)
        new_lon = current_lon + (step_lon if abs(lon_diff) > step_size else lon_diff)

        retries = 0
        while retries < retry_limit:
            try:
                # Check disaster predictions at the new location
                disaster_response = requests.get(
                    f"http://127.0.0.1:5000/get_disaster_prediction?lat={new_lat}&lon={new_lon}"
                )
                disaster_response.raise_for_status()
                disaster_data = disaster_response.json()

                # If high disaster probability, adjust the route
                high_risk = any(pred["probability"] > risk_threshold for pred in disaster_data.get("predictions", []))
                if high_risk:
                    disaster_free_path = False
                    print(f"High disaster risk at ({new_lat}, {new_lon}). Making a longer jump.")

                    # Mark the location as visited and adjust direction
                    visited_high_risk.add((new_lat, new_lon))
                    retries += 1

                    # Increase the step size substantially (make a longer jump)
                    step_size += long_jump_factor  # Increase the step size for larger jumps

                    # Calculate new coordinates after the longer jump
                    new_lat = current_lat + (step_lat + long_jump_factor if abs(lat_diff) > step_size else lat_diff)
                    new_lon = current_lon + (step_lon + long_jump_factor if abs(lon_diff) > step_size else lon_diff)
                else:
                    break  # Safe location found
            except requests.exceptions.RequestException as e:
                print(f"Error fetching disaster data for ({new_lat}, {new_lon}): {e}")
                retries += 1

        if retries >= retry_limit:
            print(f"Unable to find safe path around ({current_lat}, {current_lon}). Continuing anyway.")

        # Move to the new location
        current_lat, current_lon = new_lat, new_lon

        # Add the current point to the route path with reverse geocoding
        route_path.append({
            "lat": current_lat,
            "lon": current_lon,
            "address": get_address(current_lat, current_lon)
        })

    if iteration >= max_iterations:
        return jsonify({"error": "Failed to compute a safe route within the iteration limit."}), 500

    result = {
        "origin": {
            "lat": origin_lat,
            "lon": origin_lon,
            "address": get_address(origin_lat, origin_lon)
        },
        "destination": {
            "lat": dest_lat,
            "lon": dest_lon,
            "address": get_address(dest_lat, dest_lon)
        },
        "route_path": route_path,
        "disaster_free": disaster_free_path,
    }
    return jsonify(result)




@app.route("/emergency_tips", methods=["GET"])
def emergency_tips():
    disaster_type = request.args.get("disaster_type")
    tips = {
        "earthquake": {
            "tip": "Stay away from glass and heavy furniture.",
            "link": "https://www.ready.gov/earthquakes",
        },
        "flood": {
            "tip": "Do not walk or drive through floodwaters.",
            "link": "https://www.ready.gov/floods",
        },
        "hurricane": {
            "tip": "Have a battery-powered radio for alerts.",
            "link": "https://www.ready.gov/hurricanes",
        },
        "wildfire": {
            "tip": "Avoid smoke inhalation, evacuate when necessary.",
            "link": "https://www.ready.gov/wildfires",
        },
        "tornado": {
            "tip": "Go to a basement or a small, windowless interior room.",
            "link": "https://www.ready.gov/tornadoes",
        },
    }
    tip = tips.get(disaster_type, {"tip": "No tips available.", "link": ""})
    return jsonify(tip)



# Handle family communication
def family_communication():
    if request.method == "GET":
        # Fetch all messages with locations and timestamps
        family_data = read_family_messages()
        return jsonify({"family_data": family_data})

    elif request.method == "POST":
        # Receive the incoming JSON data for a message
        data = request.json
        message = data.get("message", "").strip()
        sender = data.get("sender", "Anonymous").strip()
        location = data.get("location", {})  # Format: {"lat": <latitude>, "lon": <longitude>}

        # Validate the data
        if not message:
            return jsonify({"error": "Message content cannot be empty."}), 400
        if not location.get("lat") or not location.get("lon"):
            return jsonify({"error": "Location (latitude and longitude) is required."}), 400

        # Create a new message data dictionary
        message_data = {
            "message": message,
            "family_member": sender,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "location": location,
        }

        # Insert the new message into the database
        write_family_message(message_data)

        return jsonify({"status": "Message sent!", "message_data": message_data})

    elif request.method == "DELETE":
        data = request.json
        index = data.get("index")

        # Delete the message from the database by index
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM messages LIMIT 1 OFFSET ?", (index,))
        row = cursor.fetchone()

        if row is None:
            return jsonify({"error": "Invalid message index."}), 400

        message_id = row[0]
        cursor.execute("DELETE FROM messages WHERE id = ?", (message_id,))
        conn.commit()
        conn.close()

        return jsonify({"status": "Message deleted!"})


# Function to read messages from the SQLite database
def read_family_messages():
    """Read messages from the SQLite database."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, family_member, message, timestamp, latitude, longitude FROM messages")
    rows = cursor.fetchall()
    conn.close()

    # Format the results into a list of dictionaries
    family_data = [{"id": row[0], "family_member": row[1], "message": row[2], "timestamp": row[3], "location": {"lat": row[4], "lon": row[5]}} for row in rows]
    return family_data


# Function to write a new message to the SQLite database
def write_family_message(message_data):
    """Write new message data to the SQLite database."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO messages (family_member, message, timestamp, latitude, longitude)
                      VALUES (?, ?, ?, ?, ?)''', 
                   (message_data['family_member'], message_data['message'], message_data['timestamp'], message_data['location']['lat'], message_data['location']['lon']))
    conn.commit()
    conn.close()

def get_family_messages():
    conn = sqlite3.connect('family_messages.db')
    conn.row_factory = sqlite3.Row  # To access rows by column name
    cursor = conn.cursor()
    cursor.execute('SELECT family_member, message, latitude, longitude, timestamp FROM messages')
    messages = cursor.fetchall()
    conn.close()
    return messages

@app.route("/family_database", methods=["GET"])
def family_database():
    # Render a page to display all family data including messages and locations
    family_data = read_family_messages()
    return render_template("family_database.html", family_data=family_data)

def get_db_connection():
    conn = sqlite3.connect('family_messages.db')
    conn.row_factory = sqlite3.Row  # Optional: For row access by column name
    return conn

@app.route('/save_message', methods=['POST'])
def save_message():
    try:
        # Parse the JSON data from the request
        data = request.get_json()
        family_member = data.get('familyMember')
        message = data.get('message')
        lat = data.get('lat')
        lon = data.get('lon')

        # Insert the message into the database
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO messages (family_member, message, latitude, longitude)
            VALUES (?, ?, ?, ?)
        ''', (family_member, message, lat, lon))
        conn.commit()
        conn.close()

        # Send a successful response
        return jsonify({'status': 'success'}), 200

    except Exception as e:
        # Handle any errors
        return jsonify({'error': str(e)}), 500


if __name__ == "__main__":
    init_db()  # Initialize the database on app startup
    app.run(debug=True)